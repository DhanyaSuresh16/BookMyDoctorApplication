import react from "react";
import '../img.css';

function Home(){
    return(
        <div >
            <img src="https://media.istockphoto.com/photos/doctor-appointment-picture-id485349446" className="img"/>
        </div>
    )
}

export default Home;