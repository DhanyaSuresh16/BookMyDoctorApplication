import React, { Component } from 'react'
import AppointmentService from '../services/AppointmentService';
import { Grid,Button,FormGroup } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
/* import Image from '@material-ui-image' */




class CreateAppointmentComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            appointmentId: this.props.match.params.id,
            appointmentDate: '',
            appointmentStatus: ''
           
        }
        // const useStyles = makeStyles({
        //     container: {
        //         width: '50%',
        //         margin: '5% 0 0 25%',
        //         '& > *': {
        //             marginTop: 20
        //         }
        //     }
        // })
        this.changeAppointmentDateHandler = this.changeAppointmentDateHandler.bind(this);
        this.changeAppointmentStatusHandler = this.changeAppointmentStatusHandler.bind(this);
        // this.changeEmailHandler=this.changeEmailHandler.bind(this);
        // this.changeTechHandler=this.changeTechHandler.bind(this);
        this.saveOrUpdateAppointment = this.saveOrUpdateAppointment.bind(this);
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.id === '_add'){
            return
        }else{
            AppointmentService.getAppointmentById(this.state.appointmentId).then( (res) =>{
                let appointment = res.data;
                this.setState({
                    appointmentDate: appointment.appointmentDate,
                    appointmentStatus : appointment.appointmentStatus
                 
                });
            });
        }        
    }
    saveOrUpdateAppointment = (e) => {
        e.preventDefault();
        let appointment = {appointmentDate: this.state.appointmentDate, appointmentStatus: this.state.appointmentStatus};
        let appointment1 = {appointmentId:this.state.appointmentId,appointmentDate: this.state.appointmentDate, appointmentStatus: this.state.appointmentStatus};
        console.log('appointment => ' + JSON.stringify(appointment1));

        // step 5
        if(this.state.appointmentId === '_add'){
            AppointmentService.createAppointment(appointment).then(res =>{
                this.props.history.push('/getAppointments');
            });
        }else{
            AppointmentService.updateAppointment(appointment1).then( res => {
                this.props.history.push('/getAppointments');
            });
        }
    }
    
    changeAppointmentDateHandler= (event) => {
        this.setState({appointmentDate: event.target.value});
    }

    changeAppointmentStatusHandler= (event) => {
        this.setState({appointmentStatus: event.target.value});
    }


    cancel(){
        this.props.history.push('/getAppointments');
    }

    getTitle(){
        if(this.state.appointmentId === '_add'){
            return <h3 className="text-center">Add Appointment</h3>
        }else{
            return <h3 className="text-center">Update Appointment</h3>
        }
       // const classes = useStyles();
    }
    render() {
        return (
            <div className="update" >
            {
                this.getTitle()
            }
            <form>
            <Grid  className="create">
                <Grid container>
                    <Grid item xs={12}>
                        <TextField name="appointmentId" value={this.state.appointmentId} label={"Id"} />
                    </Grid> 
                    <Grid item xs={12}>
                        <TextField name="appointmentDate" onChange={this.changeAppointmentDateHandler} value={this.state.appointmentDate} label={"Appointment Date"} />
                    </Grid> 
                    <Grid item xs={12}>
                        <TextField name="appointmentStatus" value={this.state.appointmentStatus} onChange={this.changeAppointmentStatusHandler} label={"Appointment Status"} />
                    </Grid> 
           
                    <Button  variant="contained"size="small" onClick={this.saveOrUpdateAppointment}>Save</Button>
                    <Button  variant="contained"size="small" onClick={this.cancel.bind(this)}>Cancel</Button>
                </Grid>
            </Grid>
        </form>
        </div>
        )
    }
}

export default CreateAppointmentComponent
