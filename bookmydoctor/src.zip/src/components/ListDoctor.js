import React, { Component } from 'react'
import DoctorService from '../services/DoctorService'
import { Route , history} from 'react-router-dom';
import {Table,TableBody,TableCell,TableContainer,TableHead,TableRow,Paper,Button,Typography,} from '@material-ui/core'

class ListDoctor extends Component {
    constructor(props) {
        super(props)

        this.state = {
                doctors: []
        }
        this.addDoctor = this.addDoctor.bind(this);
        this.editDoctor = this.editDoctor.bind(this);
        this.deleteDoctor = this.deleteDoctor.bind(this);
    }

    deleteDoctor(id){
        DoctorService.deleteDoctor(id).then( res => {
            this.setState({doctors: this.state.doctors.filter(doctor => doctor.id !== id) });
            
        });
    }
    viewDoctor(id){
        this.props.history.push(`/view-doctor/${id}`);
    }
    editDoctor(id){
        this.props.history.push(`/add-doctor/${id}`);
    }

    componentDidMount(){
        DoctorService.getDoctors().then((res) => {
            this.setState({ doctors: res.data});
        });
    }
    addDoctor(){
        this.props.history.push('/add-doctor/_add');
    }
    render() {
        return (
            <div>
                  <Button variant="contained"size="small" onClick={this.addDoctor}>Add Doctor</Button>
                 <Typography variant="h4">
                 Doctor List
                </Typography>
                 <TableContainer component={Paper} style={{marginTop:'100px'}}>
                        <Table className="material-table"aria-label="simple table">
                             <TableHead>
                                <TableRow>
                                    <TableCell>Doctor Id</TableCell>
                                    <TableCell align="center">Doctor Name</TableCell>
                                    <TableCell align="center">Speciality</TableCell>
                                    <TableCell align="center">Location</TableCell>
                                    <TableCell align="center">Hospital Name</TableCell>
                                    <TableCell align="center">BloodGroup</TableCell>
                                    <TableCell align="center">Mobile No</TableCell>
                                    <TableCell align="center">Email</TableCell>
                                    <TableCell align="center">Password</TableCell>
                                    <TableCell align="center">Charged Per Visit</TableCell>
                                </TableRow>
                            </TableHead>
                             <tbody>
                                {
                                    this.state.doctors.map(
                                        doctor => 
                                        <TableRow key = {doctor.userId}>
                                                    
                                                    <TableCell align="center">{doctor.userId}</TableCell>
                                                    <TableCell align="center">{doctor.doctorName}</TableCell>
                                                    <TableCell align="center">{doctor.speciality}</TableCell>
                                                    <TableCell align="center">{doctor.location}</TableCell>
                                                    <TableCell align="center">{doctor.hospitalName}</TableCell>
                                                    <TableCell align="center">{doctor.mobileNo}</TableCell>
                                                    <TableCell align="center">{doctor.email}</TableCell>
                                                    <TableCell align="center">{doctor.password}</TableCell>
                                                    <TableCell align="center">{doctor.chargedPerVisit}</TableCell>
                                                    <TableCell align="center">
                                                        
                                                        <Button variant="contained"size="small" onClick={ () => this.editDoctor(doctor.userId)}>Update</Button>
                                                        <Button variant="contained"size="small" onClick={ () => this.deleteDoctor(doctor.userId)}>Delete</Button>
                                                        <Button variant="contained"size="small" onClick={ () => this.viewDoctor(doctor.userId)}>View</Button>
      </TableCell>

                                                </TableRow>
                                    ) }
                            </tbody> 
                         
                 </Table>
                </TableContainer></div>
        )
    }
}

export default ListDoctor
