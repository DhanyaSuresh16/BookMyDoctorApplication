import React, { Component } from 'react'
import PatientService from '../services/PatientService';

class updatePatient extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            patientName: '',
	        mobileNo: '',
	         email: '',
	       password: '',
	        bloodGroup: '',
	       gender: '',
	       age: '',
	      address: ''
        }
        this.changePatientNameHandler = this.changePatientNameHandler.bind(this);
        this.changeMobileNoHandler = this.changeMobileNoHandler.bind(this);
        this.changeEmailHandler=this.changeEmailHandler.bind(this);
        this.changePasswordHandler=this.changePasswordHandler.bind(this);
        this.changeBloodGroupHandler = this.changeBloodGroupHandler.bind(this);
        this.changeGenderHandler = this.changeGenderHandler.bind(this);
        this.changeAgeHandler=this.changeAgeHandler.bind(this);
        this.changeAddressHandler=this.changeAddressHandler.bind(this);
        this.updatePatient = this.updatePatient.bind(this);
    }

    componentDidMount(){
        PatientService.getPatientById(this.state.id).then( (res) =>{
            let patient = res.data;
            this.setState({patientName: patient.patientName,
                mobileNo: patient.mobileNo,
                email : patient.email,
                password:patient.password,
                bloodGroup:patient.bloodGroup,
                gender:patient.gender,
                age:patient.age,
                address:patient.address
            });
        });
    }

    updatePatient = (e) => {
        e.preventDefault();
        let patient = {patientName: this.state.patientName, mobileNo: this.state.mobileNo, email: this.state.email,password:this.state.password,bloodGroup:this.state.bloodGroup,gender:this.state.gender,age:this.state.age,address:this.state.address};
        console.log('patient => ' + JSON.stringify(patient));
        console.log('id => ' + JSON.stringify(this.state.userId));
        PatientService.updatePatient(patient).then( res => {
            this.patient=res.data;
            this.props.history.push('/getPatients');
        });
    }
    
    changePatientNameHandler= (event) => {
        this.setState({patientName: event.target.value});
    }

    changeMobileNoHandler= (event) => {
        this.setState({mobileNo: event.target.value});
    }

    changeEmailHandler= (event) => {
        this.setState({email: event.target.value});
    }

    changePasswordHandler= (event) => {
        this.setState({password: event.target.value});
    }

    changeBloodGroupHandler= (event) => {
        this.setState({bloodGroup: event.target.value});
    }

    changeGenderHandler= (event) => {
        this.setState({gender: event.target.value});
    }

    changeAgeHandler= (event) => {
        this.setState({age: event.target.value});
    }

    changeAddressHandler= (event) => {
        this.setState({address: event.target.value});
    }

    cancel(){
        this.props.history.push('/getEmployees');
    }

    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Update Patient</h3>
                                <div className = "card-body">
                                    <form>
                                    <div className = "form-group">
                                            <label> Id: </label>
                                            <input placeholder="Id" name="userId" className="form-control" 
                                                value={this.state.userId} />
                                        </div>
                                        <div className = "form-group">
                                            <label> First Name: </label>
                                            <input placeholder="First Name" name="patientName" className="form-control" 
                                                value={this.state.patientName} onChange={this.changePatientNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label>Mobile No: </label>
                                            <input placeholder="Last Name" name="mobileNo" className="form-control" 
                                                value={this.state.mobileNo} onChange={this.changeMobileNoHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Email Id: </label>
                                            <input placeholder="Email Address" name="email" className="form-control" 
                                                value={this.state.email} onChange={this.changeEmailHandler}/>
                                        </div>

                                        <div className = "form-group">
                                            <label> password: </label>
                                            <input placeholder="password" name="password" className="form-control" 
                                                value={this.state.password} onChange={this.changePasswordHandler}/>
                                        </div>

                                        <div className = "form-group">
                                            <label> Blood Group: </label>
                                            <input placeholder="Blood Group" name="bloodGroup" className="form-control" 
                                                value={this.state.bloodGroup} onChange={this.changeBloodGroupHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Gender: </label>
                                            <input placeholder="Gender" name="gender" className="form-control" 
                                                value={this.state.gender} onChange={this.changeGenderHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Age: </label>
                                            <input placeholder="Age" name="age" className="form-control" 
                                                value={this.state.age} onChange={this.changeAgeHandler}/>
                                        </div>

                                        <div className = "form-group">
                                            <label> Address: </label>
                                            <input placeholder="Address" name="address" className="form-control" 
                                                value={this.state.address} onChange={this.changeAddressHandler}/>
                                        </div>

                                        <button className="btn btn-success" onClick={this.updatePatient}>Update</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default updatePatient
