import React, { Component } from 'react'
import DoctorService from '../services/DoctorService';
import { Grid,Button } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';

class CreateDoctor extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            userId: this.props.match.params.id,
            doctorName: '',
	        speciality: '',
            location: '',
            hospitalName: '',
            mobileNo: '',
            email: '',
            password: '',
            chargedPerVisit: ''
        }
        this.changeDoctorNameHandler = this.changeDoctorNameHandler.bind(this);
        this.changemobileNoHandler = this.changemobileNoHandler.bind(this);
        this.changeemailHandler = this.changeemailHandler.bind(this);
        this.changepasswordHandler=this.changepasswordHandler.bind(this);
        this.changespecialityHandler = this.changespecialityHandler.bind(this);
        this.changelocationHandler=this.changelocationHandler.bind(this);
        this.changehospitalNameHandler=this.changehospitalNameHandler.bind(this);
        this.changechargedPerVisitHandler=this.changechargedPerVisitHandler.bind(this);
        this.saveOrUpdateDoctor = this.saveOrUpdateDoctor.bind(this);

    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.id === '_add'){
            return
        }else{
            DoctorService.getDoctorById(this.state.userId).then( (res) =>{
                let doctor = res.data;
                this.setState({doctorName: doctor.doctorName,
                    mobileNo:doctor.mobileNo,
                    email:doctor.email,
                    password:doctor.password,
                    speciality: doctor.speciality,
                    location : doctor.location,
                    hospitalName:doctor.hospitalName,
                    chargedPerVisit:doctor.chargedPerVisit
                });
            });
        }        
    }
    saveOrUpdateDoctor = (e) => {
        e.preventDefault();
        let doctor = {doctorName: this.state.doctorName,mobileNo:this.state.mobileNo,email:this.state.email,password:this.state.password, speciality: this.state.speciality, location: this.state.location,hospitalName:this.state.hospitalName,chargedPerVisit:this.state.chargedPerVisit};
        let doctor1 = {userId:this.state.userId,doctorName: this.state.doctorName,mobileNo:this.state.mobileNo,email:this.state.email,password:this.state.password, speciality: this.state.speciality, location: this.state.location,hospitalName:this.state.hospitalName,chargedPerVisit:this.state.chargedPerVisit};
        console.log('doctor => ' + JSON.stringify(doctor1));

        // step 5
        if(this.state.userId === '_add'){
            DoctorService.createDoctor(doctor).then(res =>{
                this.props.history.push('/getDoctorList');
            });
        }else{
            DoctorService.updateDoctor(doctor1).then( res => {
                this.props.history.push('/getDoctorList');
            });
        }
    }
    
    changeDoctorNameHandler= (event) => {
        this.setState({doctorName: event.target.value});
    }


    changemobileNoHandler= (event) => {
        this.setState({mobileNo: event.target.value});
    }

    changeemailHandler= (event) => {
        this.setState({email: event.target.value});
    }

    changepasswordHandler= (event) => {
        this.setState({password: event.target.value});
    }

    changespecialityHandler= (event) => {
        this.setState({speciality: event.target.value});
    }

    changelocationHandler= (event) => {
        this.setState({location: event.target.value});
    }

    changehospitalNameHandler= (event) => {
        this.setState({hospitalName: event.target.value});
    }

    changechargedPerVisitHandler= (event) => {
        this.setState({chargedPerVisit: event.target.value});
    }

    cancel(){
        this.props.history.push('/getDoctorList');
    }

    getTitle(){
        if(this.state.userId === '_add'){
            return <h3 className="text-center">Add Doctor</h3>
        }else{
            return <h3 className="text-center">Update Doctor</h3>
        }
    }
    render() {
        return (
            <div className="update">
            {
                this.getTitle()
            }
            <form>
            <Grid  className="create">
                <Grid container>
                    <Grid item xs={12}>
                        <TextField name="userId" value={this.state.userId} label={"Id"} />
                    </Grid> 
                    <Grid item xs={12}>
                        <TextField name="doctorName" onChange={this.changeDoctorNameHandler} value={this.state.doctorName} label={"Doctor Name"} />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField name="mobileNo" value={this.state.mobileNo} onChange={this.changemobileNoHandler} label={"Mobile No"} />
                    </Grid> 
                    <Grid item xs={12}>
                        <TextField name="email" value={this.state.email} onChange={this.changeemailHandler} label={" Email"} />
                    </Grid> 
                    <Grid item xs={12}>
                        <TextField name="password" value={this.state.password} onChange={this.changepasswordHandler} label={"password"} />
                    </Grid> 
                    <Grid item xs={12}>
                        <TextField name="speciality" value={this.state.speciality} onChange={this.changespecialityHandler} label={"Sprecialization"} />
                    </Grid> 
                    <Grid item xs={12}>
                        <TextField name="location" value={this.state.location} onChange={this.changelocationHandler} label={"Location "} />
                    </Grid> 
                    <Grid item xs={12}>
                        <TextField name="hospitalName" value={this.state.hospitalName} onChange={this.changehospitalNameHandler} label={"Hospital Name"} />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField name="chargedPerVisit"  value={this.state.chargedPerVisit} onChange={this.changechargedPerVisitHandler} label={"Charge per visit"} />
                    </Grid>      
                    <Button variant="contained" size="small" onClick={this.saveOrUpdateDoctor}>Save</Button>
                    <Button variant="contained" size="small" onClick={this.cancel.bind(this)}>Cancel</Button>
                </Grid>
            </Grid>
        </form>
        </div>
         )
    }
}
         
export default CreateDoctor
