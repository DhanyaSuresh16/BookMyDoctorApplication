
import React, { Component } from 'react'
import AppointmentService from '../services/AppointmentService';

class UpdateAppointmentComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            appointmentDate: '',
            appointmentStatus: ''
        }
        this.changeAppointmentDateHandler = this.changeAppointmentDateHandler.bind(this);
        this.changeAppointmentStatusHandler = this.changeAppointmentStatusHandler.bind(this);
        this.updateAppointment = this.updateAppointment.bind(this);
    }

    componentDidMount(){
        AppointmentService.getAppointmentById(this.state.id).then( (res) =>{
            let appointment = res.data;
            this.setState({
                appointmentDate: appointment.appointmentDate,
                appointmentStatus : appointment.appointmentStatus
            });
        });
    }

    updateAppointment = (e) => {
        e.preventDefault();
        let appointment = {appointmentDate: this.state.appointmentDate, appointmentStatus: this.state.appointmentStatus};
        console.log('appointment => ' + JSON.stringify(appointment));
        console.log('id => ' + JSON.stringify(this.state.userId));
        AppointmentService.updateAppointment(appointment).then( res => {
            this.appointment=res.data;
            this.props.history.push('/getAppointments');
        });
    }
    
    changeAppointmentDateHandler= (event) => {
        this.setState({appointmentDate: event.target.value});
    }

    changeAppointmentStatusHandler= (event) => {
        this.setState({appointmentStatus: event.target.value});
    }


    cancel(){
        this.props.history.push('/getAppointments');
    }

    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Update Appointment</h3>
                                <div className = "card-body">
                                    <form>
                                    <div className = "form-group">
                                            <label> Appointment Id: </label>
                                            <input  name="userId" className="form-control" 
                                                value={this.state.id} />
                                        </div>
                                        <div className = "form-group">
                                            <label> Appointment Date: </label>
                                            <input placeholder="Appointment Date" name="appointmentDate" className="form-control" 
                                                value={this.state.appointmentDate} onChange={this.changeAppointmentDateHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Appointment Status: </label>
                                            <input placeholder="Appointment Status" name="appointmentStatus" className="form-control" 
                                                value={this.state.appointmentStatus} onChange={this.changeAppointmentStatusHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Email Id: </label>
                                            <input placeholder="Email Address" name="emailId" className="form-control" 
                                                value={this.state.emailId} onChange={this.changeEmailHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Tech: </label>
                                            <input placeholder="Email Address" name="emailId" className="form-control" 
                                                value={this.state.tech} onChange={this.changeTechHandler}/>
                                        </div>

                                        <button className="btn btn-success" onClick={this.updateAppointment}>Update</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default UpdateAppointmentComponent
