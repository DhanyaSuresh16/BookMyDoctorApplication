import React, { Component } from 'react'
import FeedbackService from '../services/FeedbackService'
import { Route , history} from 'react-router-dom';
import {Table,TableBody,TableCell,TableContainer,TableHead,TableRow,Paper,Button,Typography,} from '@material-ui/core'

class ListFeedback extends Component {
    constructor(props) {
        super(props)

        this.state = {
                feedbacks: []
        }
        this.addFeedback = this.addFeedback.bind(this);
        this.editFeedback = this.editFeedback.bind(this);
        this.deleteFeedback = this.deleteFeedback.bind(this);
    }

    deleteFeedback(id){
        FeedbackService.deleteFeedback(id).then( res => {
            this.setState({feedbacks: this.state.feedbacks.filter(feedback => feedback.id !== id) });
            
        });
    } 
    viewFeedback(id){
        this.props.history.push(`/view-feedback/${id}`);
    }
    editFeedback(id){
        this.props.history.push(`/add-feedBack/${id}`);
    }

    componentDidMount(){
        FeedbackService.getFeedbacks().then((res) => {
            this.setState({ feedbacks: res.data});
        });
    }
    addFeedback(){
        this.props.history.push('/add-feedback/_add');
    }
    render() {
        return (
            <div>
                  <Button variant="contained"size="small" onClick={this.addFeedback}>Add FeedBack</Button>
                 <Typography variant="h4">
                 FeedBacks List
                </Typography>
                 <TableContainer component={Paper} style={{marginTop:'100px'}}>
                        <Table className="material-table"aria-label="simple table">
                             <TableHead>
                                <TableRow>
                                    <TableCell>FeedBack Id</TableCell>
                                    <TableCell align="center">Rating</TableCell>
                                    <TableCell align="center">Feedback Details</TableCell>
                                   
                                    <TableCell align="center">Actions</TableCell>
                                </TableRow>
                            </TableHead>
                             <tbody>
                                {
                                    this.state.feedbacks.map(
                                        feedback => 
                                       <TableRow key = {feedback.feedbackId}>
                                                    
                                                    <TableCell align="center">{feedback.feedbackId}</TableCell>
                                                    <TableCell align="center">{feedback.rating}</TableCell>
                                                    <TableCell align="center">{feedback.feedback_details}</TableCell>
                                                    <TableCell align="center">
                                                        
                                                        <Button variant="contained"size="small" onClick={ () => this.editFeedback(feedback.feedbackId)}>Update</Button>
                                                        <Button variant="contained"size="small" onClick={ () => this.deleteFeedback(feedback.feedbackId)}>Delete</Button>
                                                        <Button variant="contained"size="small" onClick={ () => this.viewFeedback(feedback.feedbackId)}>View</Button>
      </TableCell>

                                                </TableRow>
                                    ) }
                            </tbody> 
                         
                 </Table>
                </TableContainer></div>
        )
    }
}

export default ListFeedback
