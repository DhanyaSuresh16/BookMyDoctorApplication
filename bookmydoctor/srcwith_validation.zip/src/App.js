import React from "react";
import {BrowserRouter as Router, Route, Routes, Switch} from 'react-router-dom'
import Navbar from "./components/HeaderComponent";
import Footer from "./components/Footercomponent";
import Home from "./components/HomeComponent";
import about from "./components/AboutComponent";
import login from "./components/LoginComponent";

import ListPatient from './components/ListPatient';
import ListPatient1 from './components/listPatients1';
import CreatePatient from './components/CreatePatient';
import viewPatient from './components/ViewPatient';

import viewDoctor from './components/ViewDoctor';
import CreateDoctor from './components/CreateDoctor';
import ListDoctor from './components/ListDoctor';
import ListDoctor1 from './components/listDoctor1';

import CreateAppointmentComponent from './components/CreateAppointmentComponent';
import ViewAppointmentComponent from './components/ViewAppointmentComponent';
import ListAppointmentComponent from './components/ListAppointmentComponent';
import ListAppointment from './components/listAppointment';
import ListAppointments from './components/listApointments';

import ListFeedBack from './components/ListFeedBack';
import CreateFeedBack from './components/CreateFeedBack';
import ViewFeedBack from './components/ViewFeedBack';

function App() {
  return (
     <div>
     <Router>
           <Navbar />
             <div className="container">
                <Switch> 
                  <Route path = "/" exact component={Home}></Route> 
                  <Route path = "/about" exact component={about}></Route>
                  <Route path = "/login" exact component={login}></Route>

                  <Route path = "/admin" exact component={ListPatient}></Route> 
                  <Route path = "/getPatients" component={ListPatient}></Route>
                  <Route path = "/add-patient/:id" component={CreatePatient}></Route>
                  <Route path = "/view-patient/:id" component={viewPatient} ></Route>

                  <Route path = "/add-doctor/:id" component={CreateDoctor}></Route>
                  <Route path = "/view-doctor/:id" component={viewDoctor} ></Route>
                  <Route path = "/getDoctorList" component={ListDoctor}></Route>
                  <Route path = "/doctorLogin" exact component={ListPatient1}></Route> 
                  
                  <Route path = "/patient" exact component={ListDoctor1}></Route> 
                  <Route path = "/appointment" exact component={ListAppointment}></Route> 
                  <Route path = "/appointment1" exact component={ListAppointmentComponent}></Route> 
                  <Route path = "/getAppointments" component={ListAppointmentComponent}></Route>
                  <Route path = "/add-appointment/:id" component={CreateAppointmentComponent}></Route>
                  <Route path = "/view-appointment/:id" component={ViewAppointmentComponent} ></Route>
                  <Route path = "/doctor" exact component={ListDoctor}></Route> 
                  <Route path = "/appointment" component={ListAppointment}></Route>
                  <Route path = "/appointment2" component={ListAppointments}></Route>

                  <Route path = "/feedback" exact component={ListFeedBack}></Route> 
                  <Route path = "/getFeedBackList" component={ListFeedBack}></Route>
                  <Route path = "/add-feedback/:id" component={CreateFeedBack}></Route>
                  <Route path = "/view-feedback/:id" component={ViewFeedBack} ></Route>
                  
                </Switch>
             </div>
           <Footer />
     </Router>
 </div>
  );
}
export default App;